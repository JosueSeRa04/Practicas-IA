import pandas as pd
from collections import Counter
import numpy as np

def cargar_archivo_csv(archivo, delimitador=','):
    # Cargar el archivo CSV
    data = pd.read_csv(archivo, delimiter=delimitador)

    # Obtener el número de atributos y patrones
    num_atributos = len(data.columns)
    num_patrones = len(data)

    print(f"Número de atributos: {num_atributos}")
    print(f"Número de patrones: {num_patrones}")

    # Obtener información de tipos de datos
    info_tipos_datos = data.dtypes

    # Mostrar información de tipos de datos
    print("\nInformación de tipos de datos:")
    print(info_tipos_datos)

    # Guardar los datos en un archivo de texto plano
    data.to_csv('datos_completos.txt', sep=delimitador, index=False)

    #Detectar valores faltantes
    valores_faltantes = data.isnull().sum() # Suma los valores faltantes por columna
    porcentaje_valores_faltantes = (valores_faltantes/ num_patrones) * 100 # Calcula el porcentaje de valores faltantes por columna

    # Mostrar valores faltantes
    print("\nValores faltantes:") 
    print(valores_faltantes)

    # Mostrar porcentaje de valores faltantes
    print("\nPorcentaje de valores faltantes:")
    print(porcentaje_valores_faltantes)

    # Calcular distribucion de clases
    clases = data.iloc[:, -1] # Selecciona la última columna
    num_muestras_por_clase = clases.value_counts() # Cuenta el número de muestras por clase
    porcentaje_muestras_por_clase = (num_muestras_por_clase / num_patrones) * 100 # Calcula el porcentaje de muestras por clase

    # Mostrar distribución de clases
    print("\nDistribución de clases:")
    print(num_muestras_por_clase)

    # Mostrar porcentaje de muestras por clase
    print("\nPorcentaje de muestras por clase:")
    print(porcentaje_muestras_por_clase)

    # Mostrar valores faltantes por atributo y por clase
    columns_to_valued = data.select_dtypes(include=['number']).columns
    print("\nValores faltantes por atributo y por clase:")
    for atributo in columns_to_valued:
        print(f"\n{atributo}:")
        for clase in data.iloc[:, -1].unique():
            faltantes_clase = data[data.iloc[:, -1] == clase][atributo].isnull().sum()
            total_clase = data[data.iloc[:, -1] == clase][atributo].count()  # Corrección aquí
            porcentaje_faltantes = (faltantes_clase / float(total_clase)) * 100 if total_clase != 0 else 0
            print(f"{clase}: {faltantes_clase} ({porcentaje_faltantes}%)")

    return data

def obtener_matriz_de_atributos(data):
    # Obtener la matriz de atributos excluyendo la columna de salida
    matriz_atributos = data.drop(columns=data.columns[-1])
    return matriz_atributos
"""
def obtener_vector_salida(data):
    # Obtener el vector de salida (última columna)
    vector_salida = data.iloc[:, -1]
    return vector_salida
"""

def seleccionar_subconjunto_atributos(data, indices):
    # Seleccionar un subconjunto de atributos
    subconjunto_atributos = data.iloc[:, indices]
    return subconjunto_atributos

def seleccionar_subconjunto_renglones(data, indices):
    # Seleccionar un subconjunto de renglones
    subconjunto_renglones = data.iloc[indices, :]
    return subconjunto_renglones

def seleccionar_vector(data, indice, renglones):
    # Seleccionar un vector de salida seleccionando los atributos
    vector_salida = data.iloc[indice, renglones]
    return vector_salida

def calcular_promedio_por_salida(data):
    # Obtener el promedio de cada atributo por salida
    promedio_por_salida = data.groupby(data.columns[Vector_salida]).mean()
    return promedio_por_salida

def calcular_distancia_euclidiana(vector1, vector2, entradas):
    # Calcular la distancia euclidiana entre dos vectores
    distancia = 0

    if len(vector1) != len(vector2):
        it = 0
        for i in entradas:
            distancia += (vector1[it] - vector2[i]) ** 2
            it += 1

    else:
        for i in range(len(entradas)):
            distancia += (vector1[i] - vector2[i]) ** 2
    return distancia ** 0.5

def calcular_distancia_manhattan(vector1, vector2, entradas):
    # Calcular la distancia de Manhattan entre dos vectores
    distancia = 0

    it = 0
    for i in entradas:
        distancia += abs(vector1[it] - vector2[i])
        it += 1
    return distancia

def obtener_vector_prueba():
    vector_prueba = input("\nIngrese el vector de prueba (separado por comas): ")
    try:
        vector_prueba = [float(x.strip()) for x in vector_prueba.split(',')]
        return vector_prueba
    except ValueError:
        print("Error: Ingrese valores numéricos separados por comas.")
        return None


def obtener_vector_entrada():
    vector_entrada = input("\nIngrese las entradas (separado por comas): ")
    try:
        vector_entrada = [int(x.strip()) for x in vector_entrada.split(',')]
        return vector_entrada
    except ValueError:
        print("Error: Ingrese valores numéricos separados por comas.")
        return None


def obtener_vector_salida():
    vector_salida = input("\nIngrese las salidas (separado por comas): ")
    try:
        vector_salida = [float(x.strip()) for x in vector_salida.split(',')]
        return vector_salida

    except ValueError:
        print("Error: Ingrese valores numéricos separados por comas.")
        return None

def normalizacion_min_max(data):
    columns_to_normalize = data.select_dtypes(include=['number']).columns

    # Itera a través de cada columna
    for column in columns_to_normalize:
        # Encuentra el valor máximo y mínimo de la columna
        max_value = data[column].max()
        min_value = data[column].min()
        
        # Normaliza los datos de la columna
        if max_value != min_value:
            data[column] = (data[column] - min_value) / (max_value - min_value)
    
    return data

def corregir_valores_atipicos(data, outliers):
    for columna, filas_atipicas in outliers.items():
        for fila in filas_atipicas:
            clase_atipico = data.iloc[fila, -1]  # Obtener la clase del valor atípico
            media_clase = data[data.iloc[:, -1] == clase_atipico][columna].mean()  # Calcular la media de la clase
            data.at[fila, columna] = media_clase  # Reemplazar el valor atípico por la media de la clase

    return data

def deteccion_y_correccion_valores_atipicos(data):
    columns_to_check = data.select_dtypes(include=['number']).columns
    outliers = {}

    for columna in columns_to_check:
        q1, q3 = data[columna].quantile([0.25, 0.75])
        iqr = q3 - q1
        lower_bound, upper_bound = q1 - 1.5 * iqr, q3 + 1.5 * iqr

        # Encontrar los valores atípicos
        atipicos = data[(data[columna] < lower_bound) | (data[columna] > upper_bound)].index

        if not atipicos.empty:
            # Mostrar los vectores con valores atípicos antes de la corrección
            print(f"Vectores con valores atípicos en la columna '{columna}':")
            print(data.iloc[atipicos])

            # Almacenar valores atípicos en el diccionario
            outliers[columna] = atipicos.tolist()

    if outliers:
        # Corregir valores atípicos reemplazándolos por el valor medio
        data_corregida = corregir_valores_atipicos(data.copy(), outliers)

        # Mostrar los vectores con valores atípicos después de la corrección
        print("\nVectores con valores atípicos después de la corrección:")
        for columna, filas_atipicas in outliers.items():
            print(f"Columna '{columna}':")
            print(data_corregida.iloc[filas_atipicas])


        return data_corregida
    else:
        print("\nNo se encontraron valores atípicos.")
        return data

""" def reducir_por_columnas_por_indices_usuario(data):
    print("Índices de las columnas disponibles:")
    for i, columna in enumerate(data.columns):
        print(f"{i}: {columna}")

    indices_columnas = input("\nIngrese los índices de las columnas que desea mantener (separados por coma): ")
    indices_columnas = [int(x.strip()) for x in indices_columnas.split(',')]

    subset_columnas = data.iloc[:, indices_columnas]
    return subset_columnas """



def reducir_por_filas_por_indices_usuario(data):
    # Preguntar sobre la cantidad total de muestras a quitar
    try:
        cantidad_total_a_eliminar = int(input("\nIngrese la cantidad total de muestras que desea eliminar: "))
    except ValueError:
        print("Error: Ingrese un valor numérico.")
        return None

    # Calcular la cantidad a eliminar por cada clase
    clases = data.iloc[:, -1]
    clases_unicas = clases.unique()
    cantidad_por_clase = cantidad_total_a_eliminar // len(clases_unicas)

    # Crear un diccionario para almacenar las clases y la cantidad a eliminar por cada una
    clases_a_eliminar = {}

    for clase in clases_unicas:
        try:
            cantidad_clase = int(input(f"\nIngrese la cantidad de muestras que desea eliminar para la clase {clase}: "))
        except ValueError:
            print("Error: Ingrese un valor numérico.")
            return None

        # Validar que la cantidad ingresada no supere la cantidad de muestras disponibles para la clase
        cantidad_maxima_a_eliminar = len(clases[clases == clase])
        if cantidad_clase > cantidad_maxima_a_eliminar:
            print(f"Error: La cantidad máxima de muestras a eliminar para la clase {clase} es {cantidad_maxima_a_eliminar}.")
            return None

        clases_a_eliminar[clase] = cantidad_clase

    # Filtrar las filas a mantener
    filas_a_mantener = []

    for clase, cantidad in clases_a_eliminar.items():
        filas_clase = data[data.iloc[:, -1] == clase].index
        filas_a_mantener.extend(np.random.choice(filas_clase, size=len(filas_clase) - cantidad, replace=False))

    # Filtrar las filas a eliminar
    filas_a_eliminar = list(set(data.index) - set(filas_a_mantener))

    # Seleccionar el subconjunto de filas
    subset_filas = data.iloc[filas_a_mantener]

    # Mostrar las filas a eliminar
    print("\nFilas a eliminar:")
    print(data.iloc[filas_a_eliminar])

    # Cantidad de filas mantenidas
    print("\nCantidad de filas mantenidas:")
    print(len(subset_filas))


    return subset_filas



# Cargar el archivo CSV
archivo_csv = 'C:/Users/josus/OneDrive/Escritorio/PythonPrograms/Parcial2/P2_Corregida/iris.csv'  # Reemplaza con la ruta de tu archivo
delimitador = ','  # Puedes cambiar el delimitador si es necesario

datos = cargar_archivo_csv(archivo_csv, delimitador)
print("\nDatos completos:")
print(datos)

# Obtener la matriz de atributos
matriz_atributos = obtener_matriz_de_atributos(datos)

# Obtener el vector de salida
# vector_salida = obtener_vector_salida(datos)

# Seleccionar un subconjunto de atributos (ejemplo: primer y tercer atributo)
indices_subconjunto_atributos = [0, 2]  # Cambia estos índices según tus necesidades
subconjunto_atributos = seleccionar_subconjunto_atributos(datos, indices_subconjunto_atributos)

# Seleccionar un subconjunto de renglones (ejemplo: primeros tres renglones)
indices_subconjunto_renglones = [0, 1, 2]  # Cambia estos índices según tus necesidades
subconjunto_renglones = seleccionar_subconjunto_renglones(datos, indices_subconjunto_renglones)

# Seleccionar un vector de salida seleccionando los atributos (ejemplo: primer renglos, primer y segundo atributo)
""" Columnas = [0,1,2,3,4]
Renglon = 0
vector_salida = seleccionar_vector(datos, Renglon, Columnas)
 """
# Normalizar los datos
print("\nDesea normalizar los datos? :")
print("1. Si")
print("2. No")
opcion = input("Ingrese el número de la opción deseada: ")
if opcion == '1':
    datos_normalizados = normalizacion_min_max(datos)
    print("\nDatos normalizados:")
    print(datos_normalizados) 
elif opcion == '2':
    print("\nDatos sin normalizar:")
    print(datos)

# Detectar valores atípicos
datos = deteccion_y_correccion_valores_atipicos(datos)

# Reducir el conjunto de datos por decision ya sea columnas o filas
print("\nDesea reducir las filas de los conjuntos de datos?")
print("1. Si")
print("2. No")
opcion = input("Ingrese el número de la opción deseada: ")
if opcion == '1':
    datos_reducidos = reducir_por_filas_por_indices_usuario(datos)
    print("\nDatos reducidos:")
    print(datos_reducidos)
    datos = datos_reducidos
elif opcion == '2':
    print("\nDatos sin reducir:")
    datos_reducidos = datos
    print(datos_reducidos)
else:
    print("Opción no válida.")

# Seleccionando los valores de entrada
print("Índices de las columnas disponibles:")
for i, columna in enumerate(datos.columns):
    print(f"{i}: {columna}")
Vector_entrada: list[int] = obtener_vector_entrada()
Vector_salida: int = int(input("Ingrese la columna de la salida o clase: "))

# Obtener el promedio de cada atributo por salida
promedio_por_salida = calcular_promedio_por_salida(datos)
print("\n\nPromedio por salida:")
print(promedio_por_salida)

# Declaramos un vector para probar los promedios
vector_prueba = obtener_vector_prueba()

# Declaramos un vector para guardar las distancias
distancias = []

# Clasificador de mínima distancia
def MinimaDistancia():
    if vector_prueba:
        # Elección del tipo de distancia
        print("\nSeleccione el tipo de distancia:")
        print("1. Distancia Euclidiana")
        print("2. Distancia de Manhattan")
        opcion = input("Ingrese el número de la opción deseada: ")
        if opcion == '1':
            # Calculamos la distancia euclidiana entre el vector de prueba y cada uno de los promedios
            for i in range(len(promedio_por_salida)):
                distancias.append(calcular_distancia_euclidiana(vector_prueba, promedio_por_salida.iloc[i, :], Vector_entrada))

            # Mostramos las distancias
            print("\nDistancias euclidianas:")
            print(distancias)

        elif opcion == '2':
            # Calculamos la distancia de Manhattan entre el vector de prueba y cada uno de los promedios
            for i in range(len(promedio_por_salida)):
                distancias.append(calcular_distancia_manhattan(vector_prueba, promedio_por_salida.iloc[i, :], Vector_entrada))

            # Mostramos las distancias
            print("\nDistancias de Manhattan:")
            print(distancias)

        else:
            print("Opción no válida. Se calculará la distancia Euclidiana por defecto.")
            # Calculamos la distancia euclidiana entre el vector de prueba y cada uno de los promedios
            for i in range(len(promedio_por_salida)):
                distancias.append(calcular_distancia_euclidiana(vector_prueba, promedio_por_salida.iloc[i, :], Vector_entrada))

            # Mostramos las distancias
            print("\nDistancias euclidianas:")
            print(distancias)


    # Determinamos la salida del vector de prueba
    salida = promedio_por_salida.index[distancias.index(min(distancias))]
    print(f"\nSalida del vector de prueba: {salida}")


# Clasificador de Vecinos cercanos (K-NN)
def Nkk():
    if vector_prueba:

        # Selección del valor de K
        Valor_k: int = int(input("\nIngrese el valor de K: "))

        distancias = []
        # Elección del tipo de distancia
        print("\nSeleccione el tipo de distancia:")
        print("1. Distancia Euclidiana")
        print("2. Distancia de Manhattan")
        opcion = input("Ingrese el número de la opción deseada: ")

        if opcion == '1':
            # Calculamos la distancia euclidiana entre el vector de prueba y cada uno de los datos
            for i in range(len(datos)):
                distancias.append([calcular_distancia_euclidiana(vector_prueba, datos.iloc[i, :], Vector_entrada), i])

            # Mostramos las distancias
            print("\nDistancias euclidianas:")
            # print(distancias)

            # Ordenando las distancias
            distancias_ordenadas = sorted(distancias, key = lambda x: x[0])

            # Determinamos la salida del vector de prueba
            Menores = distancias_ordenadas[: Valor_k]
            print(Menores)

            Resultados = []
            for i in range(Valor_k):
                Resultados.append(datos.iloc[Menores[i][1], Vector_salida])

            segundos_elementos = Resultados.copy()
            frecuencias = Counter(segundos_elementos)

            # Encuentra el valor más frecuente
            Clase_mas_frecuente = frecuencias.most_common(1)[0][0]
            print(f"\nSalida del vector de prueba: {Clase_mas_frecuente}")

        elif opcion == '2':
            # Calculamos la distancia de Manhattan entre el vector de prueba y cada uno de los datos
            for i in range(len(datos)):
                distancias.append([calcular_distancia_manhattan(vector_prueba, datos.iloc[i, :], Vector_entrada), i])

            # Mostramos las distancias
            print("\nDistancias de Manhattan:")
            # print(distancias)

            # Ordenando las distancias
            distancias_ordenadas = sorted(distancias, key=lambda x: x[0])

            # Determinamos la salida del vector de prueba
            Menores = distancias_ordenadas[: Valor_k]
            print(Menores)

            Resultados = []
            for i in range(Valor_k):
                Resultados.append(datos.iloc[Menores[i][1], Vector_salida])

            segundos_elementos = Resultados.copy()
            frecuencias = Counter(segundos_elementos)

            # Encuentra el valor más frecuente
            Clase_mas_frecuente = frecuencias.most_common(1)[0][0]
            print(f"\nSalida del vector de prueba: {Clase_mas_frecuente}")

        else:
            print("Opción no válida. Se calculará la distancia Euclidiana por defecto.")
            # Calculamos la distancia euclidiana entre el vector de prueba y cada uno de los promedios
            for i in range(len(promedio_por_salida)):
                distancias.append(calcular_distancia_euclidiana(vector_prueba, promedio_por_salida.iloc[i, :], Vector_entrada))

            # Mostramos las distancias
            print("\nDistancias euclidianas:")
            print(distancias)


# Función principal
if __name__ == "__main__":
    # Ejecutamos un menú para seleccionar el algoritmo
    print("Clasificador".center(10, '-'))
    print("[1]. Minima distancia")
    print("[2]. K-NN")
    SeleccionarDistancia: int = int(input("Seleccione la distancia deseada: "))

    # Ejecutamos el clasificador seleccionado
    if SeleccionarDistancia == 1: MinimaDistancia()
    elif SeleccionarDistancia == 2: Nkk()
    else: print("Opcion fuera de rango")