import pygame
import sys
TAMANO_CUADRO = 30
TAMANO_MUNEQUITO = 17

GRIS = (71, 75, 78)
CAFE = (161, 130, 98)
AZUL  = (59, 131, 189)
AMARILLO = (229, 190, 1)
VERDE = (0, 149, 57)
BLANCO = (255, 255, 255)
NEGRO = (0, 0, 0)
ROJO = (255, 0 ,0)
HUMANO = (253, 221, 202)       
PULPO = (87, 35, 100)    
MONO = (108, 59, 42)    

ANCHO = 450
ALTO = 450
pos_x = 0
pos_y = 0

with open('C:/Users/S ALBERT FC/Documents/ESCOM/Mapa.txt', 'r') as f:
    lineas = f.readlines()
matriz = []
for linea in lineas:
    fila = [int(valor) for valor in linea.strip().split(',')]
    matriz.append(fila)

# Inicializar Pygame
pygame.init()
ventana = pygame.display.set_mode((ANCHO, ALTO))
pygame.display.set_caption("Mapa")

paisaje = pygame.image.load("paisaje.png")  # Cargar imágenes de los personajes y paisaje 

def mostrar_menu():
    ventana.fill(BLANCO)
    
    ventana.blit(paisaje, (0, 0)) # Cargar imagen para el fondo
    pygame.display.update()

# Bucle principal del programa
ejecutando = True
while ejecutando:
    for evento in pygame.event.get():
        if evento.type == pygame.QUIT:
            ejecutando = False

        elif evento.type == pygame.KEYDOWN:
#############################################################################################################################################################
            if evento.key == pygame.K_1: # Código para el Personaje HUMANO
                fuente_v = pygame.font.Font(None, 24)
                muneco_img = pygame.Surface((TAMANO_MUNEQUITO, TAMANO_MUNEQUITO))
                muneco_img.fill(BLANCO)
                muneco_img.set_colorkey(BLANCO)
                pygame.draw.circle(muneco_img, HUMANO, (TAMANO_MUNEQUITO // 2, TAMANO_MUNEQUITO // 2), TAMANO_MUNEQUITO // 2)
                muneco_img = muneco_img.convert_alpha()

                fuente_v = pygame.font.Font(None, 20)
                fuente = pygame.font.Font(None, 20)
                areas_visitadas = [[False for _ in fila] for fila in matriz]

                def dibujar_muneco():
                    ventana.blit(muneco_img, (pos_x * TAMANO_CUADRO, pos_y * TAMANO_CUADRO))
                def sensor_mirar():
                    areas_visitadas[pos_y][pos_x] = True

                costo = 0                 
                ganado = False;
                while True:
                    for evento in pygame.event.get():
                        if evento.type == pygame.QUIT:
                            pygame.quit()
                            sys.exit()
                        elif evento.type == pygame.KEYDOWN:
                            # Mover el muñeco
                            if evento.key == pygame.K_LEFT and pos_x > 0:
                                    pos_x -= 1
                                    costo += 10 if matriz[pos_y][pos_x] == 0 else \
                                            1 if matriz[pos_y][pos_x] == 1 else \
                                            4 if matriz[pos_y][pos_x] == 2 else \
                                            3 if matriz[pos_y][pos_x] == 3 else \
                                            2 if matriz[pos_y][pos_x] == 4 else 0
                                    sensor_mirar()
                            elif evento.key == pygame.K_RIGHT and pos_x < len(matriz[0]) - 1:
                                    pos_x += 1
                                    costo += 10 if matriz[pos_y][pos_x] == 0 else \
                                            1 if matriz[pos_y][pos_x] == 1 else \
                                            4 if matriz[pos_y][pos_x] == 2 else \
                                            3 if matriz[pos_y][pos_x] == 3 else \
                                            2 if matriz[pos_y][pos_x] == 4 else 0
                                    sensor_mirar()
                            elif evento.key == pygame.K_UP and pos_y > 0:
                                    pos_y -= 1
                                    costo += 10 if matriz[pos_y][pos_x] == 0 else \
                                            1 if matriz[pos_y][pos_x] == 1 else \
                                            4 if matriz[pos_y][pos_x] == 2 else \
                                            3 if matriz[pos_y][pos_x] == 3 else \
                                            2 if matriz[pos_y][pos_x] == 4 else 0
                                    sensor_mirar()
                            elif evento.key == pygame.K_DOWN and pos_y < len(matriz) - 1:
                                    pos_y += 1
                                    costo += 10 if matriz[pos_y][pos_x] == 0 else \
                                            1 if matriz[pos_y][pos_x] == 1 else \
                                            4 if matriz[pos_y][pos_x] == 2 else \
                                            3 if matriz[pos_y][pos_x] == 3 else \
                                            2 if matriz[pos_y][pos_x] == 4 else 0
                                    sensor_mirar()
                    if pos_x == 14 and pos_y == 14:
                        ganado = True

                    for fila in range(len(matriz)):             
                        for columna in range(len(matriz[0])):
                            if matriz[fila][columna] == 0:
                                color = GRIS
                            elif matriz[fila][columna] == 1:
                                color = CAFE
                            elif matriz[fila][columna] == 2:
                                color = AZUL
                            elif matriz[fila][columna] == 3:
                                color = AMARILLO
                            elif matriz[fila][columna] == 4:
                                color = VERDE
                            pygame.draw.rect(ventana, color, (columna * TAMANO_CUADRO, fila * TAMANO_CUADRO, TAMANO_CUADRO, TAMANO_CUADRO))
                            if areas_visitadas[fila][columna]:
                                letra_v_rect = letra_v.get_rect()
                                letra_v_rect.topleft = (columna * TAMANO_CUADRO, fila * TAMANO_CUADRO)
                                ventana.blit(letra_v, letra_v_rect)

                    dibujar_muneco()
                    if ganado:
                        mensaje = '¡Haz ganado!'
                        fuente_ganado = pygame.font.Font(None, 36)
                        mensaje_renderizado = fuente_ganado.render(mensaje, True, BLANCO)
                        ventana.blit(mensaje_renderizado, (ANCHO // 2 - mensaje_renderizado.get_width() // 2, ALTO // 2 - mensaje_renderizado.get_height() // 2))
                        pygame.display.update()
                        pygame.time.delay(2500)  # Espera 5 segundos

                        pygame.quit()
                        sys.exit()

                    coordenadas = f'Coordenadas: ({pos_x}, {pos_y})'
                    texto = fuente.render(coordenadas, True, NEGRO)
                    ventana.blit(texto, (10, 10))

                    cansancio = f'Cansancio: ({costo})'
                    texto = fuente.render(cansancio, True, NEGRO)
                    ventana.blit(texto, (200, 10))

                    letra_v = fuente_v.render('V', True, ROJO)

                    inicio = f'I'
                    texto = fuente.render(inicio, True, ROJO)
                    ventana.blit(texto, (0+5, 0+5))

                    if pos_x == 14 and pos_y == 14:
                        fin = f'F'
                        texto = fuente.render(fin, True, ROJO)
                        ventana.blit(texto, (pos_x*30 + 5, pos_y*30 + 5))
                    pygame.display.update()
#############################################################################################################################################################
            elif evento.key == pygame.K_2:          # Código para el Personaje PULPO
                fuente_v = pygame.font.Font(None, 24)
                muneco_img = pygame.Surface((TAMANO_MUNEQUITO, TAMANO_MUNEQUITO))
                muneco_img.fill(BLANCO)
                muneco_img.set_colorkey(BLANCO)
                pygame.draw.circle(muneco_img, PULPO, (TAMANO_MUNEQUITO // 2, TAMANO_MUNEQUITO // 2), TAMANO_MUNEQUITO // 2)
                muneco_img = muneco_img.convert_alpha()

                fuente_v = pygame.font.Font(None, 20)
                fuente = pygame.font.Font(None, 20)
                areas_visitadas = [[False for _ in fila] for fila in matriz]

                def dibujar_muneco():
                    ventana.blit(muneco_img, (pos_x * TAMANO_CUADRO, pos_y * TAMANO_CUADRO))

                def sensor_mirar():
                    areas_visitadas[pos_y][pos_x] = True
                                        
                costo = 0                 
                ganado = False;
                while True:
                    for evento in pygame.event.get():
                        if evento.type == pygame.QUIT:
                            pygame.quit()
                            sys.exit()
                        elif evento.type == pygame.KEYDOWN:
                            # Mover el muñeco
                            if evento.key == pygame.K_LEFT and pos_x > 0 and matriz[pos_y][pos_x - 1] != 0:
                                    pos_x -= 1
                                    costo += 25 if matriz[pos_y][pos_x] == 0 else \
                                            2 if matriz[pos_y][pos_x] == 1 else \
                                            1 if matriz[pos_y][pos_x] == 2 else \
                                            3 if matriz[pos_y][pos_x] == 3 else \
                                            5 if matriz[pos_y][pos_x] == 4 else 0
                                    sensor_mirar()
                            elif evento.key == pygame.K_RIGHT and pos_x < len(matriz[0]) - 1 and matriz[pos_y][pos_x + 1] != 0:
                                    pos_x += 1
                                    costo += 25 if matriz[pos_y][pos_x] == 0 else \
                                            2 if matriz[pos_y][pos_x] == 1 else \
                                            1 if matriz[pos_y][pos_x] == 2 else \
                                            3 if matriz[pos_y][pos_x] == 3 else \
                                            5 if matriz[pos_y][pos_x] == 4 else 0
                                    sensor_mirar()
                            elif evento.key == pygame.K_UP and pos_y > 0 and matriz[pos_y - 1][pos_x] != 0:
                                    pos_y -= 1
                                    costo += 25 if matriz[pos_y][pos_x] == 0 else \
                                            2 if matriz[pos_y][pos_x] == 1 else \
                                            1 if matriz[pos_y][pos_x] == 2 else \
                                            3 if matriz[pos_y][pos_x] == 3 else \
                                            5 if matriz[pos_y][pos_x] == 4 else 0
                                    sensor_mirar()
                            elif evento.key == pygame.K_DOWN and pos_y < len(matriz) - 1 and matriz[pos_y + 1][pos_x] != 0:
                                    pos_y += 1
                                    costo += 25 if matriz[pos_y][pos_x] == 0 else \
                                            2 if matriz[pos_y][pos_x] == 1 else \
                                            1 if matriz[pos_y][pos_x] == 2 else \
                                            3 if matriz[pos_y][pos_x] == 3 else \
                                            5 if matriz[pos_y][pos_x] == 4 else 0
                                    sensor_mirar()
                    if pos_x == 14 and pos_y == 14:
                        ganado = True

                    for fila in range(len(matriz)):             
                        for columna in range(len(matriz[0])):
                            if matriz[fila][columna] == 0:
                                color = GRIS
                            elif matriz[fila][columna] == 1:
                                color = CAFE
                            elif matriz[fila][columna] == 2:
                                color = AZUL
                            elif matriz[fila][columna] == 3:
                                color = AMARILLO
                            elif matriz[fila][columna] == 4:
                                color = VERDE
                            pygame.draw.rect(ventana, color, (columna * TAMANO_CUADRO, fila * TAMANO_CUADRO, TAMANO_CUADRO, TAMANO_CUADRO))
                            if areas_visitadas[fila][columna]:
                                letra_v_rect = letra_v.get_rect()
                                letra_v_rect.topleft = (columna * TAMANO_CUADRO, fila * TAMANO_CUADRO)
                                ventana.blit(letra_v, letra_v_rect)

                    dibujar_muneco()
                    if ganado:
                        mensaje = '¡Haz ganado!'
                        fuente_ganado = pygame.font.Font(None, 36)
                        mensaje_renderizado = fuente_ganado.render(mensaje, True, BLANCO)
                        ventana.blit(mensaje_renderizado, (ANCHO // 2 - mensaje_renderizado.get_width() // 2, ALTO // 2 - mensaje_renderizado.get_height() // 2))
                        pygame.display.update()
                        pygame.time.delay(2500)  # Espera 5 segundos

                        pygame.quit()
                        sys.exit()

                    coordenadas = f'Coordenadas: ({pos_x}, {pos_y})'
                    texto = fuente.render(coordenadas, True, NEGRO)
                    ventana.blit(texto, (10, 10))

                    cansancio = f'Cansancio: ({costo})'
                    texto = fuente.render(cansancio, True, NEGRO)
                    ventana.blit(texto, (200, 10))

                    letra_v = fuente_v.render('V', True, ROJO)

                    inicio = f'I'
                    texto = fuente.render(inicio, True, ROJO)
                    ventana.blit(texto, (0+5, 0+5))

                    if pos_x == 14 and pos_y == 14:
                        fin = f'F'
                        texto = fuente.render(fin, True, ROJO)
                        ventana.blit(texto, (pos_x*30 + 5, pos_y*30 + 5))
                    pygame.display.update()
#############################################################################################################################################################
            elif evento.key == pygame.K_3:              # Código para el Personaje MONO
                fuente_v = pygame.font.Font(None, 24)
                muneco_img = pygame.Surface((TAMANO_MUNEQUITO, TAMANO_MUNEQUITO))
                muneco_img.fill(BLANCO)
                muneco_img.set_colorkey(BLANCO)
                pygame.draw.circle(muneco_img, MONO, (TAMANO_MUNEQUITO // 2, TAMANO_MUNEQUITO // 2), TAMANO_MUNEQUITO // 2)
                muneco_img = muneco_img.convert_alpha()

                fuente_v = pygame.font.Font(None, 20)
                fuente = pygame.font.Font(None, 20)
                areas_visitadas = [[False for _ in fila] for fila in matriz]

                def dibujar_muneco():
                    ventana.blit(muneco_img, (pos_x * TAMANO_CUADRO, pos_y * TAMANO_CUADRO))

                def sensor_mirar():
                    areas_visitadas[pos_y][pos_x] = True

                costo = 0         
                ganado = False;
                while True:
                    for evento in pygame.event.get():
                        if evento.type == pygame.QUIT:
                            pygame.quit()
                            sys.exit()
                        elif evento.type == pygame.KEYDOWN:
                            # Mover el muñeco
                            if evento.key == pygame.K_LEFT and pos_x > 0:
                                    pos_x -= 1
                                    costo += 10 if matriz[pos_y][pos_x] == 0 else \
                                            2 if matriz[pos_y][pos_x] == 1 else \
                                            4 if matriz[pos_y][pos_x] == 2 else \
                                            3 if matriz[pos_y][pos_x] == 3 else \
                                            1 if matriz[pos_y][pos_x] == 4 else 0
                                    sensor_mirar()
                            elif evento.key == pygame.K_RIGHT and pos_x < len(matriz[0]) - 1:
                                    pos_x += 1
                                    costo += 10 if matriz[pos_y][pos_x] == 0 else \
                                            2 if matriz[pos_y][pos_x] == 1 else \
                                            4 if matriz[pos_y][pos_x] == 2 else \
                                            3 if matriz[pos_y][pos_x] == 3 else \
                                            1 if matriz[pos_y][pos_x] == 4 else 0
                                    sensor_mirar()
                            elif evento.key == pygame.K_UP and pos_y > 0:
                                    pos_y -= 1
                                    costo += 10 if matriz[pos_y][pos_x] == 0 else \
                                            2 if matriz[pos_y][pos_x] == 1 else \
                                            4 if matriz[pos_y][pos_x] == 2 else \
                                            3 if matriz[pos_y][pos_x] == 3 else \
                                            1 if matriz[pos_y][pos_x] == 4 else 0
                                    sensor_mirar()
                            elif evento.key == pygame.K_DOWN and pos_y < len(matriz) - 1:
                                    pos_y += 1
                                    costo += 10 if matriz[pos_y][pos_x] == 0 else \
                                            2 if matriz[pos_y][pos_x] == 1 else \
                                            4 if matriz[pos_y][pos_x] == 2 else \
                                            3 if matriz[pos_y][pos_x] == 3 else \
                                            1 if matriz[pos_y][pos_x] == 4 else 0
                                    sensor_mirar()
                    if pos_x == 14 and pos_y == 14:
                        ganado = True

                    for fila in range(len(matriz)):             
                        for columna in range(len(matriz[0])):
                            if matriz[fila][columna] == 0:
                                color = GRIS
                            elif matriz[fila][columna] == 1:
                                color = CAFE
                            elif matriz[fila][columna] == 2:
                                color = AZUL
                            elif matriz[fila][columna] == 3:
                                color = AMARILLO
                            elif matriz[fila][columna] == 4:
                                color = VERDE
                            pygame.draw.rect(ventana, color, (columna * TAMANO_CUADRO, fila * TAMANO_CUADRO, TAMANO_CUADRO, TAMANO_CUADRO))
                            if areas_visitadas[fila][columna]:
                                letra_v_rect = letra_v.get_rect()
                                letra_v_rect.topleft = (columna * TAMANO_CUADRO, fila * TAMANO_CUADRO)
                                ventana.blit(letra_v, letra_v_rect)

                    dibujar_muneco()
                    if ganado:
                        mensaje = '¡Haz ganado!'
                        fuente_ganado = pygame.font.Font(None, 36)
                        mensaje_renderizado = fuente_ganado.render(mensaje, True, BLANCO)
                        ventana.blit(mensaje_renderizado, (ANCHO // 2 - mensaje_renderizado.get_width() // 2, ALTO // 2 - mensaje_renderizado.get_height() // 2))
                        pygame.display.update()
                        pygame.time.delay(2500)  # Espera 5 segundos

                        pygame.quit()
                        sys.exit()

                    coordenadas = f'Coordenadas: ({pos_x}, {pos_y})'
                    texto = fuente.render(coordenadas, True, NEGRO)
                    ventana.blit(texto, (10, 10))

                    cansancio = f'Cansancio: ({costo})'
                    texto = fuente.render(cansancio, True, NEGRO)
                    ventana.blit(texto, (200, 10))

                    letra_v = fuente_v.render('V', True, ROJO)

                    inicio = f'I'
                    texto = fuente.render(inicio, True, ROJO)
                    ventana.blit(texto, (0+5, 0+5))

                    if pos_x == 14 and pos_y == 14:
                        fin = f'F'
                        texto = fuente.render(fin, True, ROJO)
                        ventana.blit(texto, (pos_x*30 + 5, pos_y*30 + 5))
                    pygame.display.update()
#############################################################################################################################################################
    mostrar_menu()
# Finalizar Pygame
pygame.quit()