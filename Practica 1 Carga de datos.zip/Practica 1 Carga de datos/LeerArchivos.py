import pandas as pd

def cargar_archivo_csv(archivo, delimitador=','):
    # Cargar el archivo CSV
    data = pd.read_csv(archivo, delimiter=delimitador)
    
    # Obtener el número de atributos y patrones
    num_atributos = len(data.columns)
    num_patrones = len(data)
    
    print(f"Número de atributos: {num_atributos}")
    print(f"Número de patrones: {num_patrones}")
    
    # Obtener información de tipos de datos
    info_tipos_datos = data.dtypes
    
    # Mostrar información de tipos de datos
    print("\nInformación de tipos de datos:")
    print(info_tipos_datos)
    
    # Guardar los datos en un archivo de texto plano
    data.to_csv('datos_completos.txt', sep=delimitador, index=False)
    
    return data

def obtener_matriz_de_atributos(data):
    # Obtener la matriz de atributos excluyendo la columna de salida
    matriz_atributos = data.drop(columns=data.columns[-1])
    return matriz_atributos

def obtener_vector_salida(data):
    # Obtener el vector de salida (última columna)
    vector_salida = data.iloc[:, -1]
    return vector_salida

def seleccionar_subconjunto_atributos(data, indices):
    # Seleccionar un subconjunto de atributos
    subconjunto_atributos = data.iloc[:, indices]
    return subconjunto_atributos

def seleccionar_subconjunto_renglones(data, indices):
    # Seleccionar un subconjunto de renglones
    subconjunto_renglones = data.iloc[indices, :]
    return subconjunto_renglones

def seleccionar_vector(data,indice, renglones):
    # Seleccionar un vector de salida seleccionando los atributos
    vector_salida = data.iloc[indice, renglones]
    return vector_salida

# Cargar el archivo CSV
archivo_csv = 'C:/Users/josus/OneDrive/Escritorio/PythonPrograms/Parcial2/iris.csv'  # Reemplaza con la ruta de tu archivo
delimitador = ','  # Puedes cambiar el delimitador si es necesario

datos = cargar_archivo_csv(archivo_csv, delimitador)
print("\nDatos completos:")
print(datos)

# Obtener la matriz de atributos
matriz_atributos = obtener_matriz_de_atributos(datos)
print("\nMatriz de atributos:")
print(matriz_atributos)

# Obtener el vector de salida
vector_salida = obtener_vector_salida(datos)
print("\nVector de salida:")
print(vector_salida)

# Seleccionar un subconjunto de atributos (ejemplo: primer y tercer atributo)
indices_subconjunto_atributos = [0, 2]  # Cambia estos índices según tus necesidades
subconjunto_atributos = seleccionar_subconjunto_atributos(datos, indices_subconjunto_atributos)
print(f"\nSubconjunto de atributos seleccionado: {indices_subconjunto_atributos}")
print(subconjunto_atributos)

# Seleccionar un subconjunto de renglones (ejemplo: primeros tres renglones)
indices_subconjunto_renglones = [0, 1, 2]  # Cambia estos índices según tus necesidades
subconjunto_renglones = seleccionar_subconjunto_renglones(datos, indices_subconjunto_renglones)
print(f"\nSubconjunto de renglones seleccionado: {indices_subconjunto_renglones}")
print(subconjunto_renglones)

# Seleccionar un vector de salida seleccionando los atributos (ejemplo: primer renglos, primer y segundo atributo)
Columnas = [0,1,4]
Renglon = 0
vector_salida = seleccionar_vector(datos,Renglon, Columnas)
print(f"\nVector de salida seleccionado: {Renglon} columnas {Columnas}")
#print(vector_salida)

for pepe in vector_salida:
    print(pepe, end='. ')    




