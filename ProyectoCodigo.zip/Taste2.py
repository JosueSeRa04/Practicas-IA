import pygame
import heapq
import time

# Constantes para el tamaño de la pantalla y la celda
SCREEN_WIDTH = 450
SCREEN_HEIGHT = 450
TAMANO_CUADRO = 30
FPS = 2.5

# Colores
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GREEN = (0, 255, 0)
RED = (255, 0, 0)
GRIS = (71, 75, 78)
CAFE = (161, 130, 98)
AZUL  = (59, 131, 189)
AMARILLO = (229, 190, 1)
VERDE = (0, 149, 57)
BLANCO = (255, 255, 255)
NEGRO = (0, 0, 0)
ROJO = (255, 0 ,0)
HUMANO = (253, 221, 202)       
PULPO = (87, 35, 100)    
MONO = (108, 59, 42) 

# Nueva función para dibujar un solo paso del recorrido
def draw_single_step(screen, mapa, current_step):
    for fila in range(len(mapa)):             
        for columna in range(len(mapa[0])):
            if mapa[fila][columna] == 0:
                color = GRIS
            elif mapa[fila][columna] == 1:
                color = CAFE
            elif mapa[fila][columna] == 2:
                color = AZUL
            elif mapa[fila][columna] == 3:
                color = AMARILLO
            elif mapa[fila][columna] == 4:
                color = VERDE
            pygame.draw.rect(screen, color, (columna * TAMANO_CUADRO, fila * TAMANO_CUADRO, TAMANO_CUADRO, TAMANO_CUADRO))

    if current_step < len(path):
        node = path[current_step]
        pygame.draw.circle(screen, (0, 0, 255), (node[1] * TAMANO_CUADRO + TAMANO_CUADRO // 2, node[0] * TAMANO_CUADRO + TAMANO_CUADRO // 2), 10)

    pygame.display.flip()

# Lee el mapa desde el archivo "mapa.txt"
def read_map(filename):
    with open(filename, 'r') as file:
        return [[int(cell) for cell in line.strip().split(',')] for line in file]

# Clase que representa un nodo en el grafo
class Node:
    def __init__(self, x, y, cost, parent=None):
        self.x = x
        self.y = y
        self.cost = cost
        self.parent = parent

    def __lt__(self, other):
        return self.cost < other.cost

# Implementación del algoritmo A*
def astar(mapa, start, end):
    rows = len(mapa)
    cols = len(mapa[0])
    open_list = []
    closed_set = set()

    heapq.heappush(open_list, Node(start[0], start[1], 0))

    while open_list:
        current_node = heapq.heappop(open_list)

        if (current_node.x, current_node.y) == end:
            path = []
            while current_node:
                path.append((current_node.x, current_node.y))
                current_node = current_node.parent
            return path[::-1]

        closed_set.add((current_node.x, current_node.y))

        for dx, dy in [(1, 0), (-1, 0), (0, 1), (0, -1)]:
            new_x, new_y = current_node.x + dx, current_node.y + dy

            if 0 <= new_x < rows and 0 <= new_y < cols and mapa[new_x][new_y] != 4 and (new_x, new_y) not in closed_set:
                heapq.heappush(open_list, Node(new_x, new_y, current_node.cost + 1, current_node))

    return None

# Dibuja el mapa y la ruta encontrada

# Inicializa Pygame
pygame.init()
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption('A* Pathfinding')

# Lee el mapa desde el archivo
mapa = read_map('Mapa.txt')

# Coordenadas de inicio y fin
start = (2, 2)
end = (2, 6)

# Encuentra la ruta usando A*
path = astar(mapa, start, end)

# Ciclo principal
running = True
current_step = 0

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # Dibuja el mapa y la ruta
    draw_single_step(screen, mapa, current_step)


    current_step += 1
    if current_step >= len(path):
        time.sleep(1)  # Espera 1 segundo al final del recorrido
    else:
        time.sleep(1 / FPS)


    pygame.display.flip()

# Cierra Pygame al salir
pygame.quit()
